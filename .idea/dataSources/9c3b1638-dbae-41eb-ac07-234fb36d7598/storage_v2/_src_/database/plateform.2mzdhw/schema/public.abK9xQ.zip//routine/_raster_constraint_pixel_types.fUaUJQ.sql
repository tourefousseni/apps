create function "_raster_constraint_pixel_types"(rast raster) returns text[]
  stable
  strict
  language sql
as
$$
SELECT array_agg(pixeltype)::text[] FROM  public.ST_BandMetaData($1, ARRAY[]::int[]);
$$;

alter function "_raster_constraint_pixel_types"(raster) owner to postgres;

