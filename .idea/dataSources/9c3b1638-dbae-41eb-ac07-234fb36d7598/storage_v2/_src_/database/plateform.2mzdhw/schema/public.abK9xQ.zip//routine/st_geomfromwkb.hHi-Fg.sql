create function st_geomfromwkb(bytea, integer) returns geometry
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.ST_SetSRID(public.ST_GeomFromWKB($1), $2)
$$;

comment on function st_geomfromwkb(bytea, integer) is 'args: geom, srid - Makes a geometry from WKB with the given SRID';

alter function st_geomfromwkb(bytea, integer) owner to postgres;

