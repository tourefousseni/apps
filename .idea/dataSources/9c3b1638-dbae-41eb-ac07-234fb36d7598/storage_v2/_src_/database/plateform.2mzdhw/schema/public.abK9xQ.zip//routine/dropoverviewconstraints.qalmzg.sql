create function dropoverviewconstraints(ovtable name, ovcolumn name) returns boolean
  strict
  language sql
as
$$
SELECT  public.DropOverviewConstraints('', $1, $2)
$$;

comment on function dropoverviewconstraints(name, name) is 'args: ovtable, ovcolumn - Untag a raster column from being an overview of another.';

alter function dropoverviewconstraints(name, name) owner to postgres;

