create function st_intersection(rast1 raster, band1 integer, rast2 raster, band2 integer, returnband text, nodataval double precision) returns raster
  immutable
  parallel safe
  language sql
as
$$
SELECT st_intersection($1, $2, $3, $4, $5, ARRAY[$6, $6])
$$;

alter function st_intersection(raster, integer, raster, integer, text, double precision) owner to postgres;

