create function st_intersection(rast raster, band integer, geomin geometry) returns SETOF geomval
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.ST_Intersection($3, $1, $2)
$$;

alter function st_intersection(raster, integer, geometry) owner to postgres;

