create function "_drop_raster_constraint_blocksize"(rastschema name, rasttable name, rastcolumn name, axis text) returns boolean
  strict
  language plpgsql
as
$$
BEGIN
		IF lower($4) != 'width' AND lower($4) != 'height' THEN
			RAISE EXCEPTION 'axis must be either "width" or "height"';
			RETURN FALSE;
		END IF;

		RETURN  public._drop_raster_constraint($1, $2, 'enforce_' || $4 || '_' || $3);
	END;

$$;

alter function "_drop_raster_constraint_blocksize"(name, name, name, text) owner to postgres;

