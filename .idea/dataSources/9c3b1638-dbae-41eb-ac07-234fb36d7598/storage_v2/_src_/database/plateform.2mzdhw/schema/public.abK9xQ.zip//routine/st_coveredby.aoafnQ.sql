create function st_coveredby(rast1 raster, rast2 raster) returns boolean
  immutable
  parallel safe
  cost 1000
  language sql
as
$$
SELECT public.st_coveredby($1, NULL::integer, $2, NULL::integer)
$$;

comment on function st_coveredby(raster, raster) is 'args: rastA, rastB - Return true if no points of raster rastA lie outside raster rastB.';

alter function st_coveredby(raster, raster) owner to postgres;

