create function st_distance(text, text) returns double precision
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.ST_Distance($1::public.geometry, $2::public.geometry);
$$;

alter function st_distance(text, text) owner to postgres;

