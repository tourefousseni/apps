create function raster_overright(raster, raster) returns boolean
  immutable
  strict
  parallel safe
  language sql
as
$$
select $1::public.geometry &> $2::public.geometry
$$;

alter function raster_overright(raster, raster) owner to postgres;

