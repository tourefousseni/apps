create function st_resample(rast raster, ref raster, usescale boolean, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) returns raster
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.st_resample($1, $2, $4, $5, $3)
$$;

comment on function st_resample(raster, raster, boolean, text, double precision) is 'args: rast, ref, usescale, algorithm=NearestNeighbour, maxerr=0.125 - Resample a raster using a specified resampling algorithm, new dimensions, an arbitrary grid corner and a set of raster georeferencing attributes defined or borrowed from another raster.';

alter function st_resample(raster, raster, boolean, text, double precision) owner to postgres;

